<?php
/**
 * Proxy Endpoint — GF Notification Proxy
 *
 * Registers and handles the REST API route that the Zoho CRM widget calls.
 *
 * Route:   POST /wp-json/gf-proxy/v1/action
 * Auth:    X-GFP-Token header must match gfp_proxy_token in wp_options
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------------
// REGISTER REST ROUTE
// ---------------------------------------------------------------------------

add_action( 'rest_api_init', 'gfp_register_proxy_route' );

function gfp_register_proxy_route(): void {
	register_rest_route( 'gf-proxy/v1', '/action', [
		'methods'             => [ 'POST', 'OPTIONS' ],
		'callback'            => 'gfp_proxy_callback',
		'permission_callback' => '__return_true',
	] );
}

// ---------------------------------------------------------------------------
// CORS HEADERS
// ---------------------------------------------------------------------------
// WordPress sometimes strips headers added via WP_REST_Response.
// We hook into rest_pre_serve_request to send headers directly via header()
// before WordPress can interfere. We also handle OPTIONS at init level so
// preflight requests that never reach the REST router still get a response.
// ---------------------------------------------------------------------------

add_action( 'init', function() {
	if (
		isset( $_SERVER['REQUEST_METHOD'] ) &&
		$_SERVER['REQUEST_METHOD'] === 'OPTIONS' &&
		isset( $_SERVER['REQUEST_URI'] ) &&
		strpos( $_SERVER['REQUEST_URI'], '/gf-proxy/v1/' ) !== false
	) {
		header( 'Access-Control-Allow-Origin: *' );
		header( 'Access-Control-Allow-Methods: POST, OPTIONS' );
		header( 'Access-Control-Allow-Headers: Content-Type, X-GFP-Token' );
		header( 'Access-Control-Max-Age: 86400' );
		status_header( 200 );
		exit;
	}
} );

add_action( 'rest_api_init', function() {
	add_filter( 'rest_pre_serve_request', 'gfp_send_cors_headers', 10, 4 );
}, 15 );

function gfp_send_cors_headers( $served, $result, $request, $server ) {
	if ( strpos( $request->get_route(), '/gf-proxy/v1/' ) === false ) {
		return $served;
	}
	header( 'Access-Control-Allow-Origin: *' );
	header( 'Access-Control-Allow-Methods: POST, OPTIONS' );
	header( 'Access-Control-Allow-Headers: Content-Type, X-GFP-Token' );
	header( 'Access-Control-Max-Age: 86400' );
	if ( $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {
		status_header( 200 );
		exit;
	}
	return $served;
}

function gfp_add_cors_headers( $response ) {
	if ( is_wp_error( $response ) ) {
		$response = rest_ensure_response( $response );
	}
	$response->header( 'Access-Control-Allow-Origin',  '*' );
	$response->header( 'Access-Control-Allow-Methods', 'POST, OPTIONS' );
	$response->header( 'Access-Control-Allow-Headers', 'Content-Type, X-GFP-Token' );
	return $response;
}

// ---------------------------------------------------------------------------
// MAIN PROXY CALLBACK
// ---------------------------------------------------------------------------

function gfp_proxy_callback( WP_REST_Request $request ): WP_REST_Response {

	// CHECK 1 — OPTIONS preflight
	if ( $request->get_method() === 'OPTIONS' ) {
		$response = new WP_REST_Response( null, 200 );
		return gfp_add_cors_headers( $response );
	}

	// CHECK 2 — HTTPS required
	if ( ! is_ssl() ) {
		return gfp_error_response( 'https_required', 'HTTPS is required.', 400 );
	}

	// CHECK 3 — Token validation + rate limiting
	$incoming_token = $request->get_header( 'X-GFP-Token' );
	$stored_token   = get_option( 'gfp_proxy_token', '' );
	$client_ip      = gfp_get_client_ip();

	if ( gfp_is_rate_limited( $client_ip ) ) {
		gfp_log_failure( 'rate_limited', $client_ip, 'pre-action' );
		return gfp_error_response( 'invalid_token', 'Invalid token.', 401 );
	}

	if ( empty( $stored_token ) || empty( $incoming_token ) ||
	     ! hash_equals( $stored_token, $incoming_token ) ) {
		gfp_increment_rate_limit( $client_ip );
		gfp_log_failure( 'invalid_token', $client_ip, 'pre-action' );
		return gfp_error_response( 'invalid_token', 'Invalid token.', 401 );
	}

	gfp_clear_rate_limit( $client_ip );

	// CHECK 4 — Gravity Forms active
	if ( ! class_exists( 'GFAPI' ) ) {
		gfp_log_failure( 'gf_not_active', $client_ip, 'pre-action' );
		return gfp_error_response( 'gf_not_active', 'Gravity Forms is not active.', 503 );
	}

	// CHECK 5 — GF REST API enabled
	if ( ! gfp_is_gf_api_enabled() ) {
		gfp_log_failure( 'gf_api_disabled', $client_ip, 'pre-action' );
		return gfp_error_response( 'gf_api_disabled', 'Gravity Forms REST API is not enabled.', 503 );
	}

	// ROUTE TO ACTION
	$body   = $request->get_json_params();
	$action = sanitize_text_field( $body['action'] ?? '' );

	switch ( $action ) {
		case 'get_forms':
			return gfp_add_cors_headers( gfp_action_get_forms( $body, $client_ip ) );

		case 'get_form':
			return gfp_add_cors_headers( gfp_action_get_form( $body, $client_ip ) );

		case 'update_notification':
			return gfp_add_cors_headers( gfp_action_update_notification( $body, $client_ip ) );

		default:
			return gfp_add_cors_headers(
				gfp_error_response( 'invalid_action', 'Unknown action.', 400 )
			);
	}
}

// ---------------------------------------------------------------------------
// ACTION: get_forms
// ---------------------------------------------------------------------------

function gfp_action_get_forms( array $body, string $client_ip ): WP_REST_Response {

	$consumer_key = sanitize_text_field( $body['consumer_key'] ?? '' );

	if ( empty( $consumer_key ) ) {
		return gfp_error_response( 'missing_param', 'consumer_key is required.', 400 );
	}

	$gf_forms = GFAPI::get_forms();

	if ( ! is_array( $gf_forms ) ) {
		gfp_log_failure( 'gf_error', $client_ip, 'get_forms' );
		return gfp_error_response( 'gf_error', 'Could not retrieve forms from Gravity Forms.', 500 );
	}

	$forms = [];
	foreach ( $gf_forms as $form ) {
		if ( ! empty( $form['is_trash'] ) ) {
			continue;
		}
		$forms[] = [
			'id'          => (int) $form['id'],
			'title'       => (string) $form['title'],
			'entry_count' => (int) GFAPI::count_entries( $form['id'] ),
		];
	}

	return new WP_REST_Response( $forms, 200 );
}

// ---------------------------------------------------------------------------
// ACTION: get_form
// ---------------------------------------------------------------------------

function gfp_action_get_form( array $body, string $client_ip ): WP_REST_Response {

	$consumer_key    = sanitize_text_field( $body['consumer_key'] ?? '' );
	$consumer_secret = get_option( 'gfp_consumer_secret', '' );
	$form_id         = intval( $body['form_id'] ?? 0 );

	if ( empty( $consumer_key ) ) {
		return gfp_error_response( 'missing_param', 'consumer_key is required.', 400 );
	}

	if ( $form_id <= 0 ) {
		return gfp_error_response( 'missing_param', 'form_id is required.', 400 );
	}

	$form = GFAPI::get_form( $form_id );

	if ( ! $form ) {
		return gfp_error_response( 'form_not_found', 'Form not found.', 404 );
	}

	$notifications_raw = $form['notifications'] ?? [];
	$notifications     = [];

	foreach ( $notifications_raw as $notif_id => $notif ) {

		$to_value = $notif['to'] ?? '';

		if ( strpos( $to_value, '{' ) !== false ) {
			$to_type         = 'field';
			$editable        = false;
			$readonly_reason = 'merge_tag';
			$emails          = [];

		} elseif ( ! empty( $notif['routing'] ) ) {
			$to_type         = 'routing';
			$editable        = false;
			$readonly_reason = 'routing';
			$emails          = [];

		} else {
			$to_type         = 'email';
			$editable        = true;
			$readonly_reason = null;
			$emails          = array_values(
				array_filter(
					array_map( 'trim', explode( ',', $to_value ) )
				)
			);
		}

		$notifications[] = [
			'id'             => (string) $notif_id,
			'name'           => (string) ( $notif['name'] ?? 'Unnamed Notification' ),
			'toType'         => $to_type,
			'emails'         => $emails,
			'rawTo'          => $to_value,
			'editable'       => $editable,
			'readonlyReason' => $readonly_reason,
		];
	}

	return new WP_REST_Response( $notifications, 200 );
}

// ---------------------------------------------------------------------------
// ACTION: update_notification
// ---------------------------------------------------------------------------

function gfp_action_update_notification( array $body, string $client_ip ): WP_REST_Response {

	$consumer_key    = sanitize_text_field( $body['consumer_key'] ?? '' );
	$consumer_secret = get_option( 'gfp_consumer_secret', '' );
	$form_id         = intval( $body['form_id'] ?? 0 );
	$notification_id = sanitize_text_field( $body['notification_id'] ?? '' );
	$emails          = $body['emails'] ?? null;

	if ( empty( $consumer_key ) ) {
		return gfp_error_response( 'missing_param', 'consumer_key is required.', 400 );
	}

	if ( $form_id <= 0 ) {
		return gfp_error_response( 'missing_param', 'form_id is required.', 400 );
	}

	if ( empty( $notification_id ) ) {
		return gfp_error_response( 'missing_param', 'notification_id is required.', 400 );
	}

	if ( ! is_array( $emails ) || empty( $emails ) ) {
		return gfp_error_response( 'emails_empty', 'At least one email address is required.', 422 );
	}

	$failed_emails = [];
	foreach ( $emails as $email ) {
		$email = trim( (string) $email );
		if ( strpos( $email, '{' ) !== false || strpos( $email, '}' ) !== false ) {
			$failed_emails[] = $email;
			continue;
		}
		if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			$failed_emails[] = $email;
		}
	}

	if ( ! empty( $failed_emails ) ) {
		return new WP_REST_Response( [
			'code'    => 'invalid_email',
			'message' => 'One or more email addresses are not valid.',
			'failed'  => $failed_emails,
		], 422 );
	}

	$form = GFAPI::get_form( $form_id );

	if ( ! $form ) {
		return gfp_error_response( 'form_not_found', 'Form not found.', 404 );
	}

	$notifications = $form['notifications'] ?? [];

	if ( ! isset( $notifications[ $notification_id ] ) ) {
		return gfp_error_response( 'notification_not_found', 'Notification not found.', 404 );
	}

	$notification = $notifications[ $notification_id ];
	$current_to   = $notification['to'] ?? '';

	if ( strpos( $current_to, '{' ) !== false ) {
		return gfp_error_response( 'notification_readonly', 'This notification uses a dynamic recipient and cannot be edited.', 403 );
	}

	if ( ! empty( $notification['routing'] ) ) {
		return gfp_error_response( 'notification_readonly', 'This notification uses routing rules and cannot be edited.', 403 );
	}

	$previous_to = $current_to;
	$new_to      = implode( ', ', array_map( 'trim', $emails ) );

	$form['notifications'][ $notification_id ]['to'] = $new_to;

	$result = GFAPI::update_form( $form );

	if ( is_wp_error( $result ) ) {
		gfp_log_failure( 'gf_error', $client_ip, 'update_notification' );
		return gfp_error_response( 'gf_error', 'Could not save form.', 500 );
	}

	return new WP_REST_Response( [
		'success'     => true,
		'previous_to' => $previous_to,
		'new_to'      => $new_to,
	], 200 );
}

// ---------------------------------------------------------------------------
// RATE LIMITING HELPERS
// ---------------------------------------------------------------------------

function gfp_rate_limit_key( string $ip ): string {
	return 'gfp_failed_' . md5( $ip );
}

function gfp_is_rate_limited( string $ip ): bool {
	$attempts = (int) get_transient( gfp_rate_limit_key( $ip ) );
	return $attempts >= 5;
}

function gfp_increment_rate_limit( string $ip ): void {
	$key      = gfp_rate_limit_key( $ip );
	$attempts = (int) get_transient( $key );
	set_transient( $key, $attempts + 1, 900 );
}

function gfp_clear_rate_limit( string $ip ): void {
	delete_transient( gfp_rate_limit_key( $ip ) );
}

// ---------------------------------------------------------------------------
// GF API STATUS HELPERS
// ---------------------------------------------------------------------------

function gfp_is_gf_api_enabled(): bool {
	$settings = get_option( 'gravityformsaddon_gravityformswebapi_settings', [] );
	if ( ! empty( $settings['enabled'] ) ) {
		return true;
	}
	$v1_settings = get_option( 'gravityformsaddon_gravityformwebapi_settings', [] );
	return ! empty( $v1_settings['enabled'] );
}

// ---------------------------------------------------------------------------
// UTILITY HELPERS
// ---------------------------------------------------------------------------

function gfp_error_response( string $code, string $message, int $status ): WP_REST_Response {
	$response = new WP_REST_Response( [
		'code'    => $code,
		'message' => $message,
	], $status );
	return gfp_add_cors_headers( $response );
}

function gfp_get_client_ip(): string {
	if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		$ips = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
		return sanitize_text_field( trim( $ips[0] ) );
	}
	return sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' );
}

function gfp_log_failure( string $code, string $ip, string $action ): void {
	if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
		error_log( sprintf(
			'[GFProxy] %s | IP: %s | Action: %s',
			$code,
			$ip,
			$action
		) );
	}
}