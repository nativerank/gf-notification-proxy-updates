<?php
/**
 * Settings Page — GF Notification Proxy
 *
 * Renders the WP Admin settings page at Settings > GF Notification Proxy.
 * Handles saving the proxy token and auto-detecting GF API credentials.
 *
 * Options stored in wp_options:
 *   gfp_proxy_token      — proxy authentication token
 *   gfp_consumer_key     — GF API consumer key (selected from GF key list)
 *   gfp_consumer_secret  — GF API consumer secret (never displayed)
 *   gfp_setup_step_4     — boolean: connection test passed
 *   gfp_setup_step_5     — boolean: credentials test passed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------------
// REGISTER SETTINGS PAGE
// ---------------------------------------------------------------------------

add_action( 'admin_menu', 'gfp_add_settings_page' );

function gfp_add_settings_page(): void {
	add_options_page(
		'GF Notification Proxy',
		'GF Notification Proxy',
		'manage_options',
		'gf-notification-proxy',
		'gfp_render_settings_page'
	);
}

// ---------------------------------------------------------------------------
// ENQUEUE ADMIN SCRIPTS
// ---------------------------------------------------------------------------

add_action( 'admin_enqueue_scripts', 'gfp_enqueue_admin_scripts' );

function gfp_enqueue_admin_scripts( string $hook ): void {
	if ( $hook !== 'settings_page_gf-notification-proxy' ) {
		return;
	}
	// Inline JS only — no external files needed
	add_action( 'admin_footer', 'gfp_admin_inline_js' );
}

// ---------------------------------------------------------------------------
// AJAX HANDLERS
// ---------------------------------------------------------------------------

add_action( 'wp_ajax_gfp_generate_token',    'gfp_ajax_generate_token' );
add_action( 'wp_ajax_gfp_test_connection',   'gfp_ajax_test_connection' );
add_action( 'wp_ajax_gfp_test_credentials',  'gfp_ajax_test_credentials' );
add_action( 'wp_ajax_gfp_refresh_keys',      'gfp_ajax_refresh_keys' );

/**
 * Generate a new cryptographically secure proxy token.
 */
function gfp_ajax_generate_token(): void {
	check_ajax_referer( 'gfp_settings_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Unauthorized' );
	}
	$token = bin2hex( random_bytes( 32 ) );
	wp_send_json_success( [ 'token' => $token ] );
}

/**
 * Refresh the list of GF API keys from the database.
 */
function gfp_ajax_refresh_keys(): void {
	check_ajax_referer( 'gfp_settings_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Unauthorized' );
	}
	$keys = gfp_get_gf_api_keys();
	wp_send_json_success( [ 'keys' => $keys ] );
}

/**
 * Test connection to GF REST API using WordPress cookie auth.
 */
function gfp_ajax_test_connection(): void {
	check_ajax_referer( 'gfp_settings_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Unauthorized' );
	}

	if ( ! class_exists( 'GFAPI' ) ) {
		update_option( 'gfp_setup_step_4', false );
		wp_send_json_error( 'Gravity Forms is not active on this site.' );
	}

	$forms = GFAPI::get_forms();
	if ( ! is_array( $forms ) ) {
		update_option( 'gfp_setup_step_4', false );
		wp_send_json_error( 'Could not connect to Gravity Forms. Please check that GF is active.' );
	}

	$gf_version = class_exists( 'GFForms' ) ? GFForms::$version : 'unknown';
	update_option( 'gfp_setup_step_4', true );
	wp_send_json_success( [ 'message' => 'Connection successful. Gravity Forms ' . $gf_version . ' detected.' ] );
}

/**
 * Test GF credentials by attempting a read + write using stored key/secret.
 */
function gfp_ajax_test_credentials(): void {
	check_ajax_referer( 'gfp_settings_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Unauthorized' );
	}

	$consumer_key    = get_option( 'gfp_consumer_key', '' );
	$consumer_secret = get_option( 'gfp_consumer_secret', '' );

	if ( empty( $consumer_key ) || empty( $consumer_secret ) ) {
		update_option( 'gfp_setup_step_5', false );
		wp_send_json_error( 'No API key selected. Please select a GF API key and save settings first.' );
	}

	// Read test — get forms list
	$site_url  = get_site_url();
	$auth      = base64_encode( $consumer_key . ':' . $consumer_secret );
	$read_resp = wp_remote_get( $site_url . '/wp-json/gf/v2/forms', [
		'headers' => [ 'Authorization' => 'Basic ' . $auth ],
		'timeout' => 15,
	] );

	if ( is_wp_error( $read_resp ) ) {
		update_option( 'gfp_setup_step_5', false );
		wp_send_json_error( [
			'read'  => '✗ Read failed: ' . $read_resp->get_error_message(),
			'write' => '— Write test skipped',
		] );
	}

	$read_code = wp_remote_retrieve_response_code( $read_resp );
	if ( $read_code === 401 ) {
		update_option( 'gfp_setup_step_5', false );
		wp_send_json_error( [
			'read'  => '✗ Read failed: Invalid credentials (401)',
			'write' => '— Write test skipped',
		] );
	}

	if ( $read_code !== 200 ) {
		update_option( 'gfp_setup_step_5', false );
		wp_send_json_error( [
			'read'  => '✗ Read failed: HTTP ' . $read_code,
			'write' => '— Write test skipped',
		] );
	}

	// Write test — GET first form then PUT it back unchanged
	$forms     = json_decode( wp_remote_retrieve_body( $read_resp ), true );
	$write_msg = '— No forms available to test write';

	if ( ! empty( $forms ) ) {
		$first_form_id = $forms[0]['id'] ?? null;
		if ( $first_form_id ) {
			$form_resp = wp_remote_get( $site_url . '/wp-json/gf/v2/forms/' . $first_form_id, [
				'headers' => [ 'Authorization' => 'Basic ' . $auth ],
				'timeout' => 15,
			] );
			if ( ! is_wp_error( $form_resp ) ) {
				$form_body  = wp_remote_retrieve_body( $form_resp );
				$write_resp = wp_remote_request( $site_url . '/wp-json/gf/v2/forms/' . $first_form_id, [
					'method'  => 'PUT',
					'headers' => [
						'Authorization' => 'Basic ' . $auth,
						'Content-Type'  => 'application/json',
					],
					'body'    => $form_body,
					'timeout' => 15,
				] );
				if ( is_wp_error( $write_resp ) ) {
					$write_msg = '✗ Write failed: ' . $write_resp->get_error_message();
				} else {
					$write_code = wp_remote_retrieve_response_code( $write_resp );
					$write_msg  = $write_code === 200
						? '✓ Write access confirmed.'
						: '✗ Write failed: HTTP ' . $write_code . ' — ensure the API key is assigned to an Administrator user.';
				}
			}
		}
	}

	$write_passed = strpos( $write_msg, '✓' ) === 0;
	update_option( 'gfp_setup_step_5', $write_passed );

	if ( $write_passed ) {
		wp_send_json_success( [
			'read'  => '✓ Read access confirmed.',
			'write' => $write_msg,
		] );
	} else {
		wp_send_json_error( [
			'read'  => '✓ Read access confirmed.',
			'write' => $write_msg,
		] );
	}
}

// ---------------------------------------------------------------------------
// SAVE SETTINGS HANDLER
// ---------------------------------------------------------------------------

add_action( 'admin_post_gfp_save_settings', 'gfp_save_settings' );

function gfp_save_settings(): void {
	check_admin_referer( 'gfp_save_settings_action', 'gfp_save_nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Unauthorized' );
	}

	$errors = [];

	// Save proxy token
	$token = sanitize_text_field( $_POST['gfp_proxy_token'] ?? '' );
	if ( empty( $token ) ) {
		$errors[] = 'Proxy Token cannot be empty.';
	} else {
		// If token changed, reset step 4 and 5 so agent re-tests
		$existing_token = get_option( 'gfp_proxy_token', '' );
		if ( $token !== $existing_token ) {
			update_option( 'gfp_setup_step_4', false );
			update_option( 'gfp_setup_step_5', false );
		}
		update_option( 'gfp_proxy_token', $token );
	}

	// Save selected GF API key
	$selected_key_index = sanitize_text_field( $_POST['gfp_selected_key'] ?? '' );
	if ( empty( $selected_key_index ) ) {
		$errors[] = 'Please select a GF API Key.';
	} else {
		// Re-fetch keys and find the selected one by index
		$keys = gfp_get_gf_api_keys();
		if ( isset( $keys[ $selected_key_index ] ) ) {
			$key = $keys[ $selected_key_index ];
			update_option( 'gfp_consumer_key',    $key['consumer_key'] );
			update_option( 'gfp_consumer_secret', $key['consumer_secret'] );
			// Reset credential test since key changed
			update_option( 'gfp_setup_step_5', false );
		} else {
			$errors[] = 'Selected API key not found. Please refresh and try again.';
		}
	}

	if ( ! empty( $errors ) ) {
		set_transient( 'gfp_settings_errors', $errors, 30 );
		wp_redirect( admin_url( 'options-general.php?page=gf-notification-proxy&error=1' ) );
	} else {
		wp_redirect( admin_url( 'options-general.php?page=gf-notification-proxy&saved=1' ) );
	}
	exit;
}

// ---------------------------------------------------------------------------
// GF API KEY HELPER
// ---------------------------------------------------------------------------

/**
 * Read all GF REST API v2 keys directly from wp_usermeta.
 * GF stores each key pair as user meta — consumer_key and consumer_secret
 * are stored as separate meta keys prefixed with the key's hash.
 *
 * Returns array of:
 *   [
 *     'description'     => 'zohocrm',
 *     'user_login'      => 'NativeAccess',
 *     'permissions'     => 'read_write',
 *     'consumer_key'    => 'ck_...',
 *     'consumer_secret' => 'cs_...',
 *   ]
 *
 * @return array
 */
function gfp_get_gf_api_keys(): array {
	global $wpdb;

	// GF stores API keys in wp_usermeta under key 'gravityapi_key_{hash}'
	$meta_rows = $wpdb->get_results(
		"SELECT user_id, meta_key, meta_value
		 FROM {$wpdb->usermeta}
		 WHERE meta_key LIKE 'gravityapi_key_%'",
		ARRAY_A
	);

	if ( empty( $meta_rows ) ) {
		return [];
	}

	$keys = [];
	foreach ( $meta_rows as $row ) {
		$data = maybe_unserialize( $row['meta_value'] );
		if ( ! is_array( $data ) ) {
			continue;
		}

		// Get the WordPress user login for display
		$user = get_userdata( $row['user_id'] );
		$user_login = $user ? $user->user_login : 'Unknown User';

		// Determine permissions label
		$perms = $data['permissions'] ?? 'read_write';
		$perms_label = $perms === 'read_write' ? 'Read/Write' : 'Read Only';

		$keys[] = [
			'description'     => $data['description'] ?? 'API Key',
			'user_login'      => $user_login,
			'permissions'     => $perms_label,
			'consumer_key'    => $data['consumer_key']    ?? '',
			'consumer_secret' => $data['consumer_secret'] ?? '',
		];
	}

	return $keys;
}

/**
 * Find the index of the key that matches the currently saved consumer key.
 * Used to pre-select the dropdown on page load.
 *
 * @param array  $keys
 * @param string $saved_key
 * @return int|null
 */
function gfp_get_selected_key_index( array $keys, string $saved_key ): ?int {
	foreach ( $keys as $index => $key ) {
		if ( $key['consumer_key'] === $saved_key ) {
			return $index;
		}
	}
	return null;
}

// ---------------------------------------------------------------------------
// RENDER SETTINGS PAGE
// ---------------------------------------------------------------------------

function gfp_render_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$proxy_token   = get_option( 'gfp_proxy_token', '' );
	$saved_key     = get_option( 'gfp_consumer_key', '' );
	$step_4        = get_option( 'gfp_setup_step_4', false );
	$step_5        = get_option( 'gfp_setup_step_5', false );
	$nonce         = wp_create_nonce( 'gfp_settings_nonce' );
	$gf_keys       = gfp_get_gf_api_keys();
	$selected_idx  = gfp_get_selected_key_index( $gf_keys, $saved_key );
	$errors        = get_transient( 'gfp_settings_errors' );
	delete_transient( 'gfp_settings_errors' );

	// Auto-select the 'zohocrm' key if nothing is saved yet
	if ( $selected_idx === null && ! empty( $gf_keys ) ) {
		foreach ( $gf_keys as $i => $key ) {
			if ( strtolower( $key['description'] ) === 'zohocrm' ) {
				$selected_idx = $i;
				break;
			}
		}
	}

	$check = '<span style="color:#2e7d32;font-weight:bold;">✓</span>';
	$warn  = '<span style="color:#e65100;font-weight:bold;">⚠</span>';

	?>
	<div class="wrap">
		<h1>GF Notification Proxy</h1>
		<p style="color:#666;font-size:13px;">Version <?php echo esc_html( GFP_VERSION ); ?></p>

		<?php if ( isset( $_GET['saved'] ) ): ?>
			<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>
		<?php endif; ?>

		<?php if ( isset( $_GET['error'] ) && ! empty( $errors ) ): ?>
			<div class="notice notice-error is-dismissible">
				<?php foreach ( $errors as $e ): ?>
					<p><?php echo esc_html( $e ); ?></p>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if ( empty( $gf_keys ) ): ?>
			<div class="notice notice-warning">
				<p><strong>No Gravity Forms API keys found.</strong> Go to <a href="<?php echo esc_url( admin_url( 'admin.php?page=gf_settings&subview=gravityformswebapi' ) ); ?>">Forms → Settings → REST API</a> and create an API key first, then return here.</p>
			</div>
		<?php endif; ?>

		<!-- ================================================================
		     SETUP STATUS
		================================================================ -->
		<h2>Setup Status</h2>
		<ol style="line-height:2;font-size:14px;margin-left:20px;">
			<li><?php echo $check; ?> Plugin installed and active</li>
			<li><?php echo ! empty( $proxy_token ) ? $check : $warn; ?> Proxy token saved</li>
			<li><?php echo ! empty( $saved_key ) ? $check : $warn; ?> GF API key selected</li>
			<li><?php echo $step_4 ? $check : $warn; ?> Connection test passed<?php echo ! $step_4 ? ' — <em>use the Test Connection button below</em>' : ''; ?></li>
			<li><?php echo $step_5 ? $check : $warn; ?> Credentials test passed<?php echo ! $step_5 ? ' — <em>use the Test Credentials button below</em>' : ''; ?></li>
			<li><?php echo $warn; ?> Configure Zoho CRM — add <strong>Website</strong>, <strong>GF Consumer Key</strong>, and <strong>GF Proxy Token</strong> to the Account record. Ensure the GF API key is assigned to an Administrator user on this WordPress site.</li>
		</ol>

		<!-- ================================================================
		     HOW TO SET UP — DIRECTIONS
		================================================================ -->
		<div style="background:#f0f6fc;border-left:4px solid #2e6da4;padding:16px 20px;margin:24px 0;border-radius:4px;max-width:700px;">
			<h3 style="margin-top:0;color:#1a3a5c;">How to Set Up This Plugin</h3>
			<ol style="line-height:1.9;font-size:13px;margin-left:16px;">
				<li><strong>Generate a Proxy Token</strong> below and click Save. Copy this token — you will paste it into the <strong>GF Proxy Token</strong> field on the Zoho CRM Account record for this site.</li>
				<li><strong>Select the Zoho CRM API Key</strong> from the dropdown below. This should be the key labelled <strong>"zohocrm"</strong> in your Gravity Forms REST API settings. If it doesn't exist yet, go to <a href="<?php echo esc_url( admin_url( 'admin.php?page=gf_settings&subview=gravityformswebapi' ) ); ?>" target="_blank">Forms → Settings → REST API</a> and create one assigned to an <strong>Administrator user</strong>.</li>
				<li>Click <strong>Save Settings</strong>.</li>
				<li>Run <strong>Test Connection</strong> to confirm Gravity Forms is reachable.</li>
				<li>Run <strong>Test Credentials</strong> to confirm read and write access.</li>
				<li>In <strong>Zoho CRM</strong>, open the client's Account record and fill in:
					<ul style="margin-top:6px;margin-left:16px;">
						<li><strong>Website</strong> — this site's URL</li>
						<li><strong>GF Consumer Key</strong> — copy from the selected key's details in GF REST API settings</li>
						<li><strong>GF Proxy Token</strong> — the token you generated in step 1</li>
					</ul>
				</li>
			</ol>
		</div>

		<!-- ================================================================
		     SETTINGS FORM
		================================================================ -->
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:700px;">
			<input type="hidden" name="action" value="gfp_save_settings">
			<?php wp_nonce_field( 'gfp_save_settings_action', 'gfp_save_nonce' ); ?>

			<table class="form-table" role="presentation">

				<!-- PROXY TOKEN -->
				<tr>
					<th scope="row"><label for="gfp_proxy_token">Proxy Token</label></th>
					<td>
						<input
							type="text"
							id="gfp_proxy_token"
							name="gfp_proxy_token"
							value="<?php echo esc_attr( $proxy_token ); ?>"
							class="regular-text"
							autocomplete="off"
						/>
						<button type="button" id="gfp_generate_token" class="button" style="margin-left:8px;">Generate Token</button>
						<p class="description">Paste this into the <strong>GF Proxy Token</strong> field on each Zoho CRM Account record.</p>
					</td>
				</tr>

				<!-- GF API KEY SELECTOR -->
				<tr>
					<th scope="row"><label for="gfp_selected_key">GF API Key</label></th>
					<td>
						<?php if ( empty( $gf_keys ) ): ?>
							<p style="color:#c62828;">No API keys found in Gravity Forms. <a href="<?php echo esc_url( admin_url( 'admin.php?page=gf_settings&subview=gravityformswebapi' ) ); ?>">Create one here</a>, then <a href="<?php echo esc_url( admin_url( 'options-general.php?page=gf-notification-proxy' ) ); ?>">reload this page</a>.</p>
							<input type="hidden" name="gfp_selected_key" value="">
						<?php else: ?>
							<select id="gfp_selected_key" name="gfp_selected_key" class="regular-text">
								<option value="">— Select an API key —</option>
								<?php foreach ( $gf_keys as $i => $key ): ?>
									<option value="<?php echo esc_attr( $i ); ?>" <?php selected( $selected_idx, $i ); ?>>
										<?php echo esc_html( $key['description'] . ' — ' . $key['user_login'] . ' (' . $key['permissions'] . ')' ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<button type="button" id="gfp_refresh_keys" class="button" style="margin-left:8px;">↻ Refresh Keys</button>
							<p class="description">Select the <strong>zohocrm</strong> key. It must be assigned to an <strong>Administrator</strong> user. The Consumer Secret is stored securely and never displayed.</p>
						<?php endif; ?>
					</td>
				</tr>

			</table>

			<?php submit_button( 'Save Settings' ); ?>
		</form>

		<!-- ================================================================
		     CONNECTION & CREDENTIALS TESTS
		================================================================ -->
		<h2>Connection &amp; Credentials Tests</h2>
		<p style="color:#666;font-size:13px;">Run these after saving your settings. Both must pass before the Zoho CRM widget will work correctly.</p>

		<table class="form-table" role="presentation" style="max-width:700px;">
			<tr>
				<th scope="row">Test Connection</th>
				<td>
					<button type="button" id="gfp_test_connection" class="button">Test Connection</button>
					<span id="gfp_connection_result" style="margin-left:12px;font-size:13px;"></span>
					<p class="description">Confirms Gravity Forms is active and the REST API is enabled on this site.</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Test Credentials</th>
				<td>
					<button type="button" id="gfp_test_credentials" class="button">Test Credentials</button>
					<div id="gfp_credentials_result" style="margin-top:8px;font-size:13px;"></div>
					<p class="description">Verifies your selected API key can read and write via the GF API.</p>
				</td>
			</tr>
		</table>

	</div>
	<?php
}

// ---------------------------------------------------------------------------
// INLINE JAVASCRIPT
// ---------------------------------------------------------------------------

function gfp_admin_inline_js(): void {
	$nonce   = wp_create_nonce( 'gfp_settings_nonce' );
	$ajaxurl = admin_url( 'admin-ajax.php' );
	?>
	<script>
	(function() {
		var nonce   = <?php echo wp_json_encode( $nonce ); ?>;
		var ajaxurl = <?php echo wp_json_encode( $ajaxurl ); ?>;

		// --- Generate Token ---
		var generateBtn = document.getElementById('gfp_generate_token');
		if (generateBtn) {
			generateBtn.addEventListener('click', function() {
				var existingToken = document.getElementById('gfp_proxy_token').value;
				if (existingToken) {
					if (!confirm('Regenerating this token will immediately break the Zoho widget connection for this site. You will need to update the GF Proxy Token on the Zoho CRM Account record. Are you sure?')) {
						return;
					}
				}
				generateBtn.disabled = true;
				generateBtn.textContent = 'Generating…';
				fetch(ajaxurl, {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: 'action=gfp_generate_token&nonce=' + encodeURIComponent(nonce)
				})
				.then(function(r) { return r.json(); })
				.then(function(data) {
					if (data.success) {
						document.getElementById('gfp_proxy_token').value = data.data.token;
					}
				})
				.finally(function() {
					generateBtn.disabled = false;
					generateBtn.textContent = 'Generate Token';
				});
			});
		}

		// --- Refresh Keys ---
		var refreshBtn = document.getElementById('gfp_refresh_keys');
		if (refreshBtn) {
			refreshBtn.addEventListener('click', function() {
				refreshBtn.disabled = true;
				refreshBtn.textContent = 'Refreshing…';
				fetch(ajaxurl, {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: 'action=gfp_refresh_keys&nonce=' + encodeURIComponent(nonce)
				})
				.then(function(r) { return r.json(); })
				.then(function(data) {
					if (data.success && data.data.keys) {
						var select  = document.getElementById('gfp_selected_key');
						var current = select.value;
						select.innerHTML = '<option value="">— Select an API key —</option>';
						data.data.keys.forEach(function(key, i) {
							var opt = document.createElement('option');
							opt.value = i;
							opt.textContent = key.description + ' — ' + key.user_login + ' (' + key.permissions + ')';
							if (String(i) === String(current)) opt.selected = true;
							select.appendChild(opt);
						});
					}
				})
				.finally(function() {
					refreshBtn.disabled = false;
					refreshBtn.textContent = '↻ Refresh Keys';
				});
			});
		}

		// --- Test Connection ---
		var connBtn = document.getElementById('gfp_test_connection');
		if (connBtn) {
			connBtn.addEventListener('click', function() {
				connBtn.disabled = true;
				document.getElementById('gfp_connection_result').textContent = 'Testing…';
				fetch(ajaxurl, {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: 'action=gfp_test_connection&nonce=' + encodeURIComponent(nonce)
				})
				.then(function(r) { return r.json(); })
				.then(function(data) {
					var el = document.getElementById('gfp_connection_result');
					if (data.success) {
						el.style.color = '#2e7d32';
						el.textContent = '✓ ' + data.data.message;
					} else {
						el.style.color = '#c62828';
						el.textContent = '✗ ' + (data.data || 'Connection failed.');
					}
				})
				.finally(function() { connBtn.disabled = false; });
			});
		}

		// --- Test Credentials ---
		var credBtn = document.getElementById('gfp_test_credentials');
		if (credBtn) {
			credBtn.addEventListener('click', function() {
				credBtn.disabled = true;
				document.getElementById('gfp_credentials_result').innerHTML = 'Testing…';
				fetch(ajaxurl, {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: 'action=gfp_test_credentials&nonce=' + encodeURIComponent(nonce)
				})
				.then(function(r) { return r.json(); })
				.then(function(data) {
					var el   = document.getElementById('gfp_credentials_result');
					var d    = data.data || {};
					var read = d.read  || '';
					var write = d.write || '';
					var color = data.success ? '#2e7d32' : '#c62828';
					el.innerHTML =
						'<div style="color:' + (read.indexOf('✓') === 0 ? '#2e7d32' : '#c62828') + '">' + read  + '</div>' +
						'<div style="color:' + (write.indexOf('✓') === 0 ? '#2e7d32' : '#c62828') + '">' + write + '</div>';
					if ( !data.success && write.indexOf('Administrator') !== -1 ) {
						el.innerHTML += '<div style="color:#e65100;margin-top:6px;">⚠ Ensure the selected API key is assigned to an Administrator user in <a href="' + <?php echo wp_json_encode( admin_url( 'admin.php?page=gf_settings&subview=gravityformswebapi' ) ); ?> + '" target="_blank">GF REST API settings</a>.</div>';
					}
				})
				.finally(function() { credBtn.disabled = false; });
			});
		}
	})();
	</script>
	<?php
}