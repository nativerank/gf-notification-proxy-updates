<?php
/**
 * Plugin Name: GF Notification Proxy
 * Description: Allows Zoho CRM agents to manage Gravity Forms notification recipients
 *              directly from the customer's Account record — without WordPress access.
 * Version:     1.1.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 *
 * This is the plugin bootstrap file. Its only jobs are:
 *   1. Declare the plugin to WordPress (via the header above)
 *   2. Check that the server meets minimum requirements on activation
 *   3. Initialise the auto-update checker so client sites get updates automatically
 *   4. Load the rest of the plugin files (settings page, proxy endpoint)
 *
 * Nothing else belongs here. Business logic lives in /includes/.
 */

// Block direct file access — if WordPress isn't loaded, there's nothing useful here.
// ABSPATH is a constant WordPress defines. If it's missing, someone is hitting this
// file directly in a browser, which we never want.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------------
// CONSTANTS
// ---------------------------------------------------------------------------

/**
 * Plugin version — single source of truth.
 * Referenced by the update checker and the settings page version display.
 * When shipping a new release, bump this value and update info.json on the
 * update server to match.
 */
define( 'GFP_VERSION', '1.1.0 );

/**
 * Absolute path to the plugin root directory, with trailing slash.
 * Used for require_once calls throughout the plugin so paths are always
 * relative to this file, not to wherever WordPress happens to be.
 */
define( 'GFP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * URL to the update server's info.json manifest.
 * The plugin-update-checker library polls this URL to detect new versions.
 */
define( 'GFP_UPDATE_SERVER_URL', 'https://gf-notification-proxy-updates.vercel.app/info.json' );

// ---------------------------------------------------------------------------
// ACTIVATION HOOK — version check
// ---------------------------------------------------------------------------

/**
 * Runs once when an administrator clicks "Activate" on this plugin.
 *
 * We check PHP and WordPress version requirements here rather than at
 * runtime, because if either is too old the plugin simply won't work —
 * better to refuse cleanly than to throw cryptic errors later.
 *
 * If requirements aren't met:
 *   - We store a flag in a transient so the admin notice can display.
 *   - We immediately deactivate the plugin so it doesn't stay "active"
 *     in a broken state.
 */
register_activation_hook( __FILE__, 'gfp_activation_check' );

function gfp_activation_check(): void {

	$errors = [];

	// Check PHP version. PHP_VERSION is a built-in PHP constant.
	if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
		$errors[] = sprintf(
			'PHP 8.0 or higher is required. Your server is running PHP %s.',
			PHP_VERSION
		);
	}

	// Check WordPress version. $wp_version is a global WordPress sets before
	// any plugins load — we can rely on it being present here.
	global $wp_version;
	if ( version_compare( $wp_version, '6.0', '<' ) ) {
		$errors[] = sprintf(
			'WordPress 6.0 or higher is required. This site is running WordPress %s.',
			$wp_version
		);
	}

	if ( ! empty( $errors ) ) {
		// Store the error messages so our admin notice hook can display them.
		// We use a short-lived transient (60 seconds is plenty — the page will
		// reload immediately after deactivation and the notice will show).
		set_transient( 'gfp_activation_error', $errors, 60 );

		// Deactivate the plugin. We need to include this file because the
		// deactivate_plugins() function lives there, and it may not be loaded
		// yet at activation time.
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		deactivate_plugins( plugin_basename( __FILE__ ) );

		// Returning here stops the rest of the activation hook from running.
		return;
	}
}

// ---------------------------------------------------------------------------
// ADMIN NOTICE — shown after failed activation
// ---------------------------------------------------------------------------

/**
 * Displays an error notice in WP Admin if activation failed the version check.
 *
 * WordPress fires the 'admin_notices' action on every admin page load.
 * We check for our transient; if it exists, we display the errors and
 * delete the transient so the notice only shows once.
 */
add_action( 'admin_notices', 'gfp_activation_error_notice' );

function gfp_activation_error_notice(): void {

	$errors = get_transient( 'gfp_activation_error' );

	if ( empty( $errors ) ) {
		return;
	}

	// Delete the transient immediately — we only want to show this once.
	delete_transient( 'gfp_activation_error' );

	// WordPress admin notice markup. The 'notice-error' class gives it a red
	// left border. 'is-dismissible' adds the × close button.
	echo '<div class="notice notice-error is-dismissible"><p><strong>GF Notification Proxy could not be activated:</strong></p><ul>';

	foreach ( $errors as $error ) {
		echo '<li>' . esc_html( $error ) . '</li>';
	}

	echo '</ul></div>';
}

// ---------------------------------------------------------------------------
// AUTO-UPDATE CHECKER
// ---------------------------------------------------------------------------

/**
 * Initialises the YahnisElsts Plugin Update Checker library.
 *
 * This library hooks into WordPress's native update system. When WP checks
 * for plugin updates, the library polls GFP_UPDATE_SERVER_URL, reads the
 * version number from info.json, and surfaces an "Update available" notice
 * in WP Admin → Plugins if a newer version exists.
 *
 * The library file must exist at lib/plugin-update-checker/plugin-update-checker.php.
 * If it's missing (e.g. during development before the library is installed),
 * we skip initialisation rather than throwing a fatal error.
 */
function gfp_init_update_checker(): void {

	$library_path = GFP_PLUGIN_DIR . 'lib/plugin-update-checker/plugin-update-checker.php';

	if ( ! file_exists( $library_path ) ) {
		// Library not installed — update checking won't work, but the rest of
		// the plugin will still function normally. Log a notice for developers.
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[GFProxy] Plugin Update Checker library not found. Auto-updates disabled.' );
		}
		return;
	}

	require_once $library_path;

	// The library uses a namespace-based factory. PucFactory::buildUpdateChecker()
	// accepts three arguments:
	//   1. URL to the info.json manifest on our update server
	//   2. Path to this plugin's main file (so WP knows which plugin to update)
	//   3. The plugin slug (must match the folder name of the plugin)
	//
	// We reference the class with its full namespace path rather than a `use`
	// statement because `use` is only valid at the top of a file, not inside
	// a function body — putting it here would cause a fatal parse error.
	\YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		GFP_UPDATE_SERVER_URL,
		__FILE__,
		'gf-notification-proxy'
	);
}

// 'plugins_loaded' fires after all active plugins are loaded. It's the
// standard hook for initialising plugin functionality that doesn't need
// to run earlier.
add_action( 'plugins_loaded', 'gfp_init_update_checker' );

// ---------------------------------------------------------------------------
// LOAD PLUGIN FILES
// ---------------------------------------------------------------------------

/**
 * Load the settings page and proxy endpoint.
 *
 * We use require_once (not include) because these files are essential —
 * if they're missing, the plugin cannot function and we want a clear PHP
 * fatal error rather than silent failure.
 */
require_once GFP_PLUGIN_DIR . 'includes/settings-page.php';
require_once GFP_PLUGIN_DIR . 'includes/proxy-endpoint.php';